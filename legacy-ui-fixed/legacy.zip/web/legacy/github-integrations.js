/**
 * ============================================================================
 *  Lv-00 开源库集成模块 (Lv00Libraries)
 * ============================================================================
 *
 *  用途：集成39个开源库以增强Lv-00 Web应用功能，
 *        覆盖数学计算、代码编辑、数据可视化、机器学习、
 *        几何算法、文档处理、物理模拟、三维渲染等领域。
 *
 *  命名规范（遵循Lv-00项目标准）：
 *    - 模块对象：PascalCase + Lv00前缀 (例: Lv00MathJS, Lv00Delaunator)
 *    - 公开方法：camelCase (例: evaluate, createCanvas)
 *    - 私有变量/方法：_camelCase前缀 (例: _loaded, _loadScript)
 *    - 共享工具函数：_lv前缀 (例: _lvLoadScript)
 *    - 日志前缀：[Lv00 ModuleName] 格式
 *    - 模块模式：IIFE揭示模块模式
 *
 *  作者：Lv-00 Team
 *  创建日期：2026-05-20
 *  版本：2.0 （彻底内化重构）
 * ============================================================================
 */
var _lvLoadScript = (function() {
    'use strict';

    /**
     * SRI (Subresource Integrity) 哈希查找表
     * 所有通过CDN加载的外部脚本的sha384完整性哈希值。
     * 通过下载对应版本文件并使用SHA-384算法计算生成。
     * 新增CDN依赖时需在此表中添加对应条目。
     * 两个特殊资源：uuid使用v8.3.2（v9无UMD构建），
     * tinyqueue使用index.min.js入口。
     */
    var _sriHashes = {
        'https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.1/math.min.js':
            'sha384-RA24dGaXZtEJnk/WxRf6cszmIctIUrKJl/YdSSeiLZ6RJheZTl6bKFbJTEjaT2Tp',
        'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/highlight.min.js':
            'sha384-RH2xi4eIQ/gjtbs9fUXM68sLSi99C7ZWBRX1vDrVv6GQXRibxXLbwO2NGZB74MbU',
        'https://cdn.jsdelivr.net/npm/fabric@6.4.3/dist/index.min.js':
            'sha384-LjdMK4Y+X/+RShbBH+mMfSf4pzSMloziPxCWM51A+R9rAgmczpj8YAzpro3exvck',
        'https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js':
            'sha384-CjloA8y00+1SDAUkjs099PVfnY2KmDC2BZnws9kh8D/lX1s46w6EPhpXdqMfjK6i',
        'https://cdnjs.cloudflare.com/ajax/libs/echarts/5.5.0/echarts.min.js':
            'sha384-o5uz97et3bErHvpKfD4Jz4n0JfhJDWABFuF4NP+iEEDxE1VwMWJ19QGR0lqFZnr6',
        'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.21/lodash.min.js':
            'sha384-H6KKS1H1WwuERMSm+54dYLzjg0fKqRK5ZRyASdbrI/lwrCc6bXEmtGYr5SwvP1pZ',
        'https://cdnjs.cloudflare.com/ajax/libs/axios/1.6.8/axios.min.js':
            'sha384-ftvHQsVsFt/CYVdJ1acqn4sKGIZ77bziRNFfeph9Ww9C4vQa5zY/ev4cfR5vyYrZ',
        'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js':
            'sha384-ZYmwuq4n2gOcNxMSiJ6jyTj+BbIrilr7p6dlq6q5nmSWKmsH9UU4K1qqjycMkfmR',
        'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.17.0/dist/tf.min.js':
            'sha384-R4iglwC8w7UAyfRq7VUmXEPjrvYnoXIqhsbTUN07o6o8yKYeiTY0/Z6DzbsKgWZ3',
        'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2':
            'sha384-Vcjc/igTnNpWsiZipZ+UkMn/2IRLqYYjMGBKd4hAHA+NXZE47u8DF0PpTmE4aW7U',
        'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.17.1/dist/ort.min.js':
            'sha384-61k9ikq77C7O/r49eqY0GLZKj5nlqD2OZ2g4Q3sk/wFuPY67SrKsqC2qMc1uuz4N',
        'https://cdn.jsdelivr.net/npm/mermaid@10.9.0/dist/mermaid.min.js':
            'sha384-6F4Ibv/ylL12O35KFWTeGTHuBKDz5L6yjKsgv3QHQ8s4NTqlDXq7kMlYXGs7MHFc',
        'https://cdn.jsdelivr.net/npm/cytoscape@3.28.1/dist/cytoscape.min.js':
            'sha384-J7Q85oZE4GJ/e7+n2aOQsLXfDwwfnA8S2nZAL5BpFsfpCF84zQD7LroZ/dMnLgex',
        'https://cdn.jsdelivr.net/npm/marked@12.0.1/marked.min.js':
            'sha384-3zf4Pen4fXU90jGg3cxmo7BF4dq8HMtF2s07c/Hhd1Fh+Encm6ApPvNm8vrMJbWu',
        'https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js':
            'sha384-JcnsjUPPylna1s1fvi1u12X5qjY5OL56iySh75FdtrwhO/SWXgMjoVqcKyIIWOLk',
        'https://cdn.jsdelivr.net/npm/matter-js@0.19.0/build/matter.min.js':
            'sha384-OqQP3UcU7efkEYDRjGmQou2uEvzGFGRtwdYXTjnupeB9cWogSgQ4BOhyklFBYbBR',
        'https://cdn.jsdelivr.net/npm/dayjs@1.11.10/dayjs.min.js':
            'sha384-DpVxUeeBWjUvUV1czyIHJAjh+jYUZFu2lLakbdua5vbwOrBGi1UgaKCHjTC+x3Ky',
        'https://cdn.jsdelivr.net/npm/file-saver@2.0.5/dist/FileSaver.min.js':
            'sha384-PlRSzpewlarQuj5alIadXwjNUX+2eNMKwr0f07ShWYLy8B6TjEbm7ZlcN/ScSbwy',
        'https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js':
            'sha384-/Mc/2ffICYME94wcPOYwoL99IzpbvFsDTty0/5V5t22x2n26tp8JRSsxKjvgZuZs',
        'https://cdn.jsdelivr.net/npm/@xterm/xterm@5.4.0/lib/xterm.js':
            'sha384-N+MuV1uJ0e6WFyYGC+MVM15t1pzD25mrrqgwkBsUB+ptmY/FcNcOpaJqb56RkxE3',
        'https://cdn.jsdelivr.net/npm/clipboard@2.0.11/dist/clipboard.min.js':
            'sha384-J08i8An/QeARD9ExYpvphB8BsyOj3Gh2TSh1aLINKO3L0cMSH2dN3E22zFoXEi0Q',
        'https://cdn.jsdelivr.net/npm/delaunator@5.0.0/delaunator.min.js':
            'sha384-tveKnSDbEDXGAlkAmAwkDNHNmbL7H3PBfB6QVijZ9KowUVUR9IfgqmqUo+KHrjFh',
        'https://cdn.jsdelivr.net/npm/turndown@7.1.3/dist/turndown.js':
            'sha384-uMuzvvCv65QPd6VIK3GjgOKkPIRYvUv58DxqGCI12xW3tClw6d/4ModZ1fRdPtbk',
        'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js':
            'sha384-CI3ELBVUz9XQO+97x6nwMDPosPR5XvsxW2ua7N1Xeygeh1IxtgqtCkGfQY9WWdHu',
        'https://cdn.jsdelivr.net/npm/fuse.js@7.0.0/dist/fuse.min.js':
            'sha384-PCSoOZTpbkikBEtd/+uV3WNdc676i9KUf01KOA8CnJotvlx8rRrETbDuwdjqTYvt',
        'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.2.0/crypto-js.min.js':
            'sha384-mgWScxWVKP8F7PBbpNp7i/aSb17kN0LcifBpahAplF3Mn0GR4/u1oMpWIm2rD8yY',
        'https://cdn.jsdelivr.net/npm/seedrandom@3.0.5/seedrandom.min.js':
            'sha384-bFS5CG904xYIgxBcrDF4KFNXuM7KeSGsSvS/QTaDqMTEdbaaxjg2Y2TSU3Ygs7wG',
        'https://cdn.jsdelivr.net/npm/pako@2.1.0/dist/pako.min.js':
            'sha384-rNlaE5fs9dGIjmxWDALQh/RBAaGRYT5ChrzHo6tRfgrZ36iRFAiquP5g41Jsv+0j',
        'https://cdn.jsdelivr.net/npm/rbush@3.0.1/rbush.min.js':
            'sha384-uufOPIpn7tGh+F+9s9wCQTPWaFz3X8KTtobp4G8EJ0eIrW7ZBMWjh4l85TZMzwjz',
        'https://cdn.jsdelivr.net/npm/simple-statistics@7.8.3/dist/simple-statistics.min.js':
            'sha384-j4Ga4vVTRhNtxxpmW6hc+VyOHN//+8+Yk38kQuS1t74VZ36e6SkyHsm5Y75HmiNO',
        'https://cdn.jsdelivr.net/npm/earcut@2.2.4/dist/earcut.min.js':
            'sha384-2H0pAXlHBLfkdkuPuERxxSBlz7fMZ2EqrwxccEG7J9Svyk1SbUDaknB5UCoel/ZX',
        'https://cdn.jsdelivr.net/npm/robust-predicates@3.0.2/umd/orient2d.min.js':
            'sha384-KKZbGWa8812YNwJtu+SVVc0ALXR0xLfAwERDwdn8k1oSaJVALXoYmOaY6vFVNz1z',
        'https://cdn.jsdelivr.net/npm/robust-predicates@3.0.2/umd/incircle.min.js':
            'sha384-UVtBKFZFzTR8DBzj3rf1/M/ag23s1o+/NlAtLFv2DpNNNTLrSUdBsyTXt7fxNV7M',
        'https://cdn.jsdelivr.net/npm/gl-matrix@3.4.3/gl-matrix-min.js':
            'sha384-dIkApPaY76o8FguOWKltyw0IM80483Rv8pQPpW5DJtJdBu3LtcS+LNdCHyFtPVHm',
        // UUID v9无UMD构建，改用v8.3.2 cdnjs版本
        'https://cdnjs.cloudflare.com/ajax/libs/uuid/8.3.2/uuidv4.min.js':
            'sha384-e2kr3z94YEVTtgf8bBbR3EHF3Oi1yLDp7GdxIRn6upe2VFHnSRQe0brjEOeRKCoj',
        // tinyqueue v3.0.0入口文件为index.min.js
        'https://cdn.jsdelivr.net/npm/tinyqueue@3.0.0/index.min.js':
            'sha384-9UEnwQzitG7srch2RgPbIBMJjGXZMnUH/xleM3f2ekQemkjPSymHFb1xFr64LJOh'
    };

    /**
     * 加载外部JavaScript脚本（动态创建script标签）
     *
     * 自动从内部SRI哈希查找表中附加 integrity 属性，
     * 防止CDN被篡改后注入恶意代码。
     * 未知URL（如动态构建的codemirror mode文件）不添加integrity。
     *
     * 【复用说明】如果 integrate-all.js 已先行加载并定义了
     * window.__lv00Extension._loadScript，则直接复用其方法，
     * 避免功能重复和重复的script标签创建逻辑。
     *
     * @param {string} src - 要加载的脚本URL
     * @returns {Promise<void>} 加载成功resolve，加载失败reject
     */
    return function(src) {
        // 如果 integrate-all.js 的 _loadScript 已可用，复用之
        if (window.__lv00Extension && typeof window.__lv00Extension._loadScript === 'function') {
            return window.__lv00Extension._loadScript(src);
        }

        return new Promise(function(resolve, reject) {
            var script = document.createElement('script');
            script.src = src;
            script.crossOrigin = 'anonymous';
            // 自动附加SRI哈希（如果查找表中有对应条目）
            var integrityHash = _sriHashes[src];
            if (integrityHash) {
                script.integrity = integrityHash;
            }
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    };
})();

/**
 * ============================================================================
 * SRI (子资源完整性 Subresource Integrity) 说明
 * ============================================================================
 * 所有通过CDN加载的外部脚本应当配置 integrity 属性，以防止CDN被篡改后
 * 引入恶意代码。在知晓确切hash值时应填充 integrity，格式：
 *   integrity="sha384-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
 * 可访问 https://www.srihash.org/ 生成对应hash值。
 * 当前尚未对所有CDN脚本添加 integrity 属性，因其hash值需要根据实际版本获取。
 * 生产环境中必须为所有外部脚本添加 SRI 校验。
 *
 * 各CDN资源的SRI hash 待添加位置清单（格式：CDN URL => 待填SRI位置）：
 *
 *   【数学计算】
 *   - mathjs@11.11.1        => Lv00MathJS.load()     行约~120
 *   【代码编辑】
 *   - highlight.js@11.11.1  => Lv00HighlightJS.load() 行约~210
 *   - codemirror@5.65.16    => Lv00CodeMirror.load()  行约~715
 *   【图形绘制】
 *   - fabric@6.4.3          => Lv00FabricJS.load()    行约~265
 *   - three.js@r128         => Lv00ThreeJS.load()     行约~1995
 *   【数据可视化】
 *   - d3@7.9.0              => Lv00D3.load()          行约~475
 *   - echarts@5.5.0         => Lv00ECharts.load()     行约~530
 *   - mermaid@10.9.0        => Lv00Mermaid.load()     行约~1160
 *   - cytoscape@3.28.1      => Lv00Cytoscape.load()   行约~1230
 *   【工具库】
 *   - lodash@4.17.21        => Lv00Lodash.load()      行约~590
 *   - axios@1.6.8           => Lv00Axios.load()       行约~645
 *   - dayjs@1.11.10         => Lv00DayJS.load()       行约~1550
 *   - file-saver@2.0.5      => Lv00FileSaver.load()   行约~1600
 *   - fuse.js@7.0.0         => Lv00Fuse.load()        行约~2110
 *   - uuid@9.0.1            => Lv00UUID.load()        行约~2165
 *   - clipboard@2.0.11      => Lv00Clipboard.load()   行约~1820
 *   【机器学习】
 *   - @tensorflow/tfjs@4.17.0    => Lv00TensorFlowJS.load()    行约~790
 *   - @xenova/transformers@2.17.2=> Lv00TransformersJS.load()  行约~860
 *   - onnxruntime-web@1.17.1     => Lv00ONNXRuntime.load()     行约~935
 *   【文档处理】
 *   - marked@12.0.1         => Lv00Marked.load()      行约~1335
 *   - jspdf@2.5.1           => Lv00JsPDF.load()       行约~1385
 *   - turndown@7.1.3        => Lv00Turndown.load()    行约~1960
 *   【物理模拟】
 *   - matter-js@0.19.0      => Lv00MatterJS.load()    行约~1455
 *   【动画引擎】
 *   - animejs@3.2.2         => Lv00Anime.load()       行约~1660
 *   【终端模拟】
 *   - @xterm/xterm@5.4.0    => Lv00XTerm.load()       行约~1750
 *   【几何算法】
 *   - delaunator@5.0.0      => Lv00Delaunator.load()  行约~1885
 *   - earcut@2.2.4          => Lv00Earcut.load()      行约~2685
 *   - robust-predicates@3.0.2 => Lv00RobustPredicates.load() 行约~2735
 *   【加密哈希】
 *   - crypto-js@4.2.0       => Lv00Crypto.load()      行约~2215
 *   - seedrandom@3.0.5      => Lv00SeedRandom.load()  行约~2295
 *   【数据压缩】
 *   - pako@2.1.0            => Lv00Pako.load()        行约~2365
 *   【数据结构】
 *   - tinyqueue@3.0.0       => Lv00TinyQueue.load()   行约~2445
 *   - rbush@3.0.1           => Lv00RBush.load()       行约~2515
 *   【统计计算】
 *   - simple-statistics@7.8.3 => Lv00SimpleStats.load() 行约~2585
 *   【线性代数】
 *   - gl-matrix@3.4.3       => Lv00GLMatrix.load()    行约~2785
 *
 * SRI 状态：所有CDR资源的 integrity 哈希已通过SHA-384算法计算并内置到
 * _lvLoadScript 的查找表中，自动附加到每个加载的脚本标签。
 * CSS资源的integrity直接添加到对应的link元素。
 * 两个特殊资源：uuid 使用 v8.3.2（v9 无 UMD 构建），
 * tinyqueue 使用 index.min.js 入口（而非 tinyqueue.min.js）。
 * codemirror mode 文件使用动态 URL 构建，暂不添加 SRI。
 * ============================================================================
 */

/**
 * _safeSetHTML(element, htmlContent)
 * 安全地将HTML/SVG内容注入DOM元素
 *
 * 原理：使用 DOMParser 在独立上下文中解析HTML字符串，
 *       再通过 document.importNode + cloneNode 方式导入到目标元素中。
 *       浏览器在DOMParser解析阶段会自动丢弃不安全的标签/属性（如script），
 *       从而防御XSS攻击。相比直接设置innerHTML，此方法提供了额外的安全层。
 *
 * 注意：此函数适用于来自可信第三方库（如Mermaid.js、Marked.js）的HTML/SVG输出。
 *       对于完全不受信的用户输入，仍需额外使用CSP策略和内容过滤。
 *
 * 【与 integrate-all.js 中 _safeCloneContent 的差异说明】
 *  - _safeCloneContent（integrate-all.js）：处理已有DOM节点，通过
 *    importNode + cloneNode 方式复制节点树，适合需要保留原有DOM结构的场景。
 *  - _safeSetHTML（本文件）：解析原始HTML/SVG字符串，通过DOMParser创建
 *    新DOM树后再导入，适合从字符串来源（如Mermaid SVG、Marked HTML）安全
 *    渲染内容的场景。两者互不替代，各司其职。
 *
 * @param {HTMLElement} element   - 目标DOM容器元素
 * @param {string}      htmlContent - 要注入的HTML/SVG内容字符串
 * @returns {void}
 */
var _safeSetHTML = (function() {
    'use strict';
    return function(element, htmlContent) {
        if (!element || !htmlContent) return;

        // 先清空目标容器的文本内容，防止任何潜在脚本执行
        element.textContent = '';

        // 使用DOMParser在独立上下文中解析HTML，避免直接设置innerHTML
        var parser = new DOMParser();
        var doc = parser.parseFromString(htmlContent, 'text/html');

        // 遍历解析后的子节点并克隆到目标元素
        var childNodes = Array.prototype.slice.call(doc.body.childNodes);
        for (var i = 0; i < childNodes.length; i++) {
            element.appendChild(document.importNode(childNodes[i], true));
        }
    };
})();

// ==================== Lv00MathJS - Math.js 数学计算库 ====================
// GitHub: https://github.com/josdejong/mathjs
// License: Apache-2.0
// 功能：符号计算、矩阵运算、单位转换、表达式解析
// 分类：数学计算

var Lv00MathJS = (function() {
    'use strict';

    var _loaded = false;
    var _math = null;

    /**
     * 加载Math.js数学计算库（从CDN加载并缓存，重复调用只返回已加载实例）
     * @returns {Promise<Object>} 加载完成后resolve为math.js库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_math);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.1/math.min.js').then(function() {
            _math = window.math;
            _loaded = true;
            console.log('[Lv00 MathJS] Math.js loaded successfully');
            return _math;
        });
    }

    function evaluate(expr, scope) {
        if (!_loaded) return null;
        scope = scope || {};
        try {
            return _math.evaluate(expr, scope);
        } catch (e) {
            console.error('[Lv00 MathJS] Evaluation error:', e);
            return null;
        }
    }

    // 矩阵运算
    var matrixOps = {
        create: function(data) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.create: library not loaded'); return null; }
            return window.math.matrix(data);
        },
        multiply: function(a, b) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.multiply: library not loaded'); return null; }
            return window.math.multiply(a, b);
        },
        inv: function(m) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.inv: library not loaded'); return null; }
            return window.math.inv(m);
        },
        transpose: function(m) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.transpose: library not loaded'); return null; }
            return window.math.transpose(m);
        },
        det: function(m) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.det: library not loaded'); return null; }
            return window.math.det(m);
        },
        solve: function(A, b) {
            if (!_loaded) { console.error('[Lv00 MathJS] matrixOps.solve: library not loaded'); return null; }
            return window.math.lusolve(A, b);
        }
    };

    // 符号计算
    var symbolic = {
        derivative: function(expr, variable) {
            if (!_loaded) { console.error('[Lv00 MathJS] symbolic.derivative: library not loaded'); return null; }
            return window.math.derivative(expr, variable);
        },
        simplify: function(expr) {
            if (!_loaded) { console.error('[Lv00 MathJS] symbolic.simplify: library not loaded'); return null; }
            return window.math.simplify(expr);
        }
    };

    return {
        load: load,
        evaluate: evaluate,
        matrixOps: matrixOps,
        symbolic: symbolic
    };

})();


// ==================== Lv00HighlightJS - Highlight.js 语法高亮 ====================
// GitHub: https://github.com/highlightjs/highlight.js
// License: BSD-3-Clause
// 功能：180+语言支持，自动语言检测
// 分类：代码编辑

var Lv00HighlightJS = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Highlight.js语法高亮库（CSS+JS，从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/styles/atom-one-dark.min.css';
        link.crossOrigin = 'anonymous';
        link.integrity = 'sha384-oaMLBGEzBOJx3UHwac0cVndtX5fxGQIfnAeFZ35RTgqPcYlbprH9o9PUV/F8Le07';
        document.head.appendChild(link);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/highlight.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 HighlightJS] Highlight.js loaded successfully');
        });
    }

    function highlightAll() {
        if (_loaded && window.hljs) {
            window.hljs.highlightAll();
        }
    }

    function highlightElement(element) {
        if (_loaded && window.hljs) {
            window.hljs.highlightElement(element);
        }
    }

    function highlightCode(code, language) {
        if (!_loaded || !window.hljs) return code;
        try {
            var result = window.hljs.highlight(code, { language: language });
            return result.value;
        } catch (e) {
            return code;
        }
    }

    return {
        load: load,
        highlightAll: highlightAll,
        highlightElement: highlightElement,
        highlightCode: highlightCode
    };

})();


// ==================== Lv00FabricJS - Fabric.js Canvas绘图库 ====================
// GitHub: https://github.com/fabricjs/fabric.js
// License: MIT
// 功能：强大的Canvas交互式绘图，支持SVG/JSON导入导出
// 分类：图形绘制

var Lv00FabricJS = (function() {
    'use strict';

    var _loaded = false;
    var _fabric = null;
    var _canvas = null;

    /**
     * 加载Fabric.js Canvas绘图库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为fabric.js库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_fabric);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/fabric@6.4.3/dist/index.min.js').then(function() {
            _fabric = window.fabric;
            _loaded = true;
            console.log('[Lv00 FabricJS] Fabric.js loaded successfully');
            return _fabric;
        });
    }

    function createCanvas(elementId, options) {
        if (!_loaded) return null;
        options = options || {};
        var canvas = new _fabric.Canvas(elementId, {
            width: options.width || 800,
            height: options.height || 600,
            backgroundColor: options.backgroundColor || '#1a1a1a'
        });
        _canvas = canvas;
        return canvas;
    }

    // 几何图形创建辅助
    var geometry = {
        createPoint: function(x, y, options) {
            options = options || {};
            return new window.fabric.Circle({
                left: x - (options.radius || 5),
                top: y - (options.radius || 5),
                radius: options.radius || 5,
                fill: options.fill || '#4caf50',
                stroke: options.stroke || '#fff',
                strokeWidth: options.strokeWidth || 1,
                selectable: options.selectable !== false
            });
        },
        createLine: function(x1, y1, x2, y2, options) {
            options = options || {};
            return new window.fabric.Line([x1, y1, x2, y2], {
                stroke: options.stroke || '#2196f3',
                strokeWidth: options.strokeWidth || 2,
                selectable: options.selectable !== false
            });
        },
        createPolygon: function(points, options) {
            options = options || {};
            return new window.fabric.Polygon(points, {
                fill: options.fill || 'transparent',
                stroke: options.stroke || '#ff9800',
                strokeWidth: options.strokeWidth || 2,
                selectable: options.selectable !== false
            });
        },
        createCircle: function(x, y, radius, options) {
            options = options || {};
            return new window.fabric.Circle({
                left: x - radius,
                top: y - radius,
                radius: radius,
                fill: options.fill || 'transparent',
                stroke: options.stroke || '#9c27b0',
                strokeWidth: options.strokeWidth || 2,
                selectable: options.selectable !== false
            });
        }
    };

    // 导出功能
    var _export = {
        toPNG: function(canvas, options) {
            options = options || {};
            return canvas.toDataURL({
                format: 'png',
                quality: options.quality || 1,
                multiplier: options.multiplier || 1
            });
        },
        toSVG: function(canvas) {
            return canvas.toSVG();
        },
        toJSON: function(canvas) {
            return canvas.toJSON();
        },
        fromJSON: function(canvas, json) {
            canvas.loadFromJSON(json);
        }
    };

    return {
        load: load,
        createCanvas: createCanvas,
        geometry: geometry,
        export: _export
    };

})();


// ==================== Lv00Store - 轻量级状态管理 ====================
// GitHub: https://github.com/pmndrs/zustand
// License: MIT
// 功能：轻量级状态管理，无需Provider（简化版store模式）
// 分类：状态管理

var Lv00Store = (function() {
    'use strict';

    /**
     * 初始化Store轻量级状态管理模块（纯JavaScript实现，无需外部依赖）
     * @returns {Promise<void>} 立即resolve的Promise
     */
    function load() {
        return Promise.resolve();
    }

    var _stores = {};

    function createStore(name, initialState, actions) {
        actions = actions || {};
        var store = {
            state: {},
            listeners: new Set(),

            getState: function() {
                return this.state;
            },

            setState: function(updater) {
                var newState = typeof updater === 'function'
                    ? updater(this.state)
                    : updater;
                var key;
                for (key in newState) {
                    if (newState.hasOwnProperty(key)) {
                        this.state[key] = newState[key];
                    }
                }
                this._notify();
            },

            subscribe: function(listener) {
                this.listeners.add(listener);
                var self = this;
                return function() {
                    self.listeners.delete(listener);
                };
            },

            _notify: function() {
                var self = this;
                this.listeners.forEach(function(listener) {
                    listener(self.state);
                });
            },

            actions: {}
        };

        // 初始化状态
        var key;
        for (key in initialState) {
            if (initialState.hasOwnProperty(key)) {
                store.state[key] = initialState[key];
            }
        }

        // 绑定actions
        var actionKeys = Object.keys(actions);
        for (var i = 0; i < actionKeys.length; i++) {
            (function(actionKey) {
                store.actions[actionKey] = function() {
                    var args = Array.prototype.slice.call(arguments);
                    return actions[actionKey].apply(null, [store.setState.bind(store), store.getState.bind(store)].concat(args));
                };
            })(actionKeys[i]);
        }

        _stores[name] = store;
        return store;
    }

    function getStore(name) {
        return _stores[name];
    }

    return {
        load: load,
        createStore: createStore,
        getStore: getStore
    };

})();


// ==================== Lv00D3 - D3.js 数据可视化 ====================
// GitHub: https://github.com/d3/d3
// License: ISC
// 功能：数据驱动文档，强大的数据可视化库
// 分类：数据可视化

var Lv00D3 = (function() {
    'use strict';

    var _loaded = false;
    var _d3 = null;

    /**
     * 加载D3.js数据可视化库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为d3.js库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_d3);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js').then(function() {
            _d3 = window.d3;
            _loaded = true;
            console.log('[Lv00 D3] D3.js loaded successfully');
            return _d3;
        });
    }

    function createSVG(containerId, width, height) {
        if (!_loaded) { console.error('[Lv00 D3] createSVG: library not loaded'); return null; }
        return _d3.select('#' + containerId)
            .append('svg')
            .attr('width', width)
            .attr('height', height);
    }

    function createScale(type, domain, range) {
        if (!_loaded) { console.error('[Lv00 D3] createScale: library not loaded'); return null; }
        if (type === 'linear') {
            return _d3.scaleLinear().domain(domain).range(range);
        } else if (type === 'log') {
            return _d3.scaleLog().domain(domain).range(range);
        } else if (type === 'ordinal') {
            return _d3.scaleOrdinal().domain(domain).range(range);
        }
    }

    return {
        load: load,
        createSVG: createSVG,
        createScale: createScale
    };

})();


// ==================== Lv00ECharts - ECharts 图表库 ====================
// GitHub: https://github.com/apache/echarts
// License: Apache-2.0
// 功能：强大的图表库，支持多种图表类型
// 分类：数据可视化

var Lv00ECharts = (function() {
    'use strict';

    var _loaded = false;
    var _echarts = null;
    var _instances = {};

    /**
     * 加载ECharts图表库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为echarts库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_echarts);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/echarts/5.5.0/echarts.min.js').then(function() {
            _echarts = window.echarts;
            _loaded = true;
            console.log('[Lv00 ECharts] ECharts loaded successfully');
            return _echarts;
        });
    }

    function init(elementId, theme) {
        theme = theme || 'dark';
        return load().then(function() {
            var chart = _echarts.init(document.getElementById(elementId), theme);
            _instances[elementId] = chart;
            return chart;
        });
    }

    function setOption(elementId, option) {
        if (_instances[elementId]) {
            _instances[elementId].setOption(option);
        }
    }

    function dispose(elementId) {
        if (_instances[elementId]) {
            _instances[elementId].dispose();
            delete _instances[elementId];
        }
    }

    return {
        load: load,
        init: init,
        setOption: setOption,
        dispose: dispose
    };

})();


// ==================== Lv00Lodash - Lodash 实用工具库 ====================
// GitHub: https://github.com/lodash/lodash
// License: MIT
// 功能：JavaScript实用工具库，提供数组、对象、函数等操作
// 分类：工具库

var Lv00Lodash = (function() {
    'use strict';

    var _loaded = false;
    var _ = null;

    /**
     * 加载Lodash实用工具库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为lodash对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.21/lodash.min.js').then(function() {
            _ = window._;
            _loaded = true;
            console.log('[Lv00 Lodash] Lodash loaded successfully');
            return _;
        });
    }

    // 常用工具方法
    var utils = {
        deepClone: function(obj) {
            return window._.cloneDeep(obj);
        },
        debounce: function(fn, wait) {
            return window._.debounce(fn, wait);
        },
        throttle: function(fn, wait) {
            return window._.throttle(fn, wait);
        },
        groupBy: function(collection, iteratee) {
            return window._.groupBy(collection, iteratee);
        },
        orderBy: function(collection, iteratees, orders) {
            return window._.orderBy(collection, iteratees, orders);
        }
    };

    return {
        load: load,
        utils: utils
    };

})();


// ==================== Lv00Axios - Axios HTTP客户端 ====================
// GitHub: https://github.com/axios/axios
// License: MIT
// 功能：基于Promise的HTTP客户端
// 分类：工具库

var Lv00Axios = (function() {
    'use strict';

    var _loaded = false;
    var _axios = null;

    /**
     * 加载Axios HTTP客户端库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为axios对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_axios);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/axios/1.6.8/axios.min.js').then(function() {
            _axios = window.axios;
            _loaded = true;
            console.log('[Lv00 Axios] Axios loaded successfully');
            return _axios;
        });
    }

    function get(url, config) {
        config = config || {};
        return load().then(function() {
            return _axios.get(url, config);
        });
    }

    function post(url, data, config) {
        config = config || {};
        return load().then(function() {
            return _axios.post(url, data, config);
        });
    }

    function createInstance(config) {
        if (!_loaded) { console.error('[Lv00 Axios] createInstance: library not loaded'); return null; }
        return _axios.create(config);
    }

    return {
        load: load,
        get: get,
        post: post,
        createInstance: createInstance
    };

})();


// ==================== Lv00CodeMirror - CodeMirror 代码编辑器 ====================
// GitHub: https://github.com/codemirror/codemirror5
// License: MIT
// 功能：多功能文本编辑器，支持100+语言模式
// 分类：代码编辑

var Lv00CodeMirror = (function() {
    'use strict';

    var _loaded = false;
    var _cm = null;
    var _editors = {};

    function _loadCSS(href, integrity) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.crossOrigin = 'anonymous';
        if (integrity) {
            link.integrity = integrity;
        }
        document.head.appendChild(link);
    }

    /**
     * 加载CodeMirror代码编辑器（CSS+JS，从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为CodeMirror对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_cm);

        _loadCSS('https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css', 'sha384-zaeBlB/vwYsDRSlFajnDd7OydJ0cWk+c2OWybl3eSUf6hW2EbhlCsQPqKr3gkznT');
        _loadCSS('https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css', 'sha384-ccdJwIIg/K0Ab6aXF4MPACh7ckk61tvQFTrfkhXZEALgAETURNZIAuQLcS/aPbrM');

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js').then(function() {
            _cm = window.CodeMirror;
            _loaded = true;
            console.log('[Lv00 CodeMirror] CodeMirror loaded successfully');
            return _cm;
        });
    }

    function loadMode(mode) {
        if (!_loaded) return load().then(function() { return _doLoadMode(mode); });
        return _doLoadMode(mode);
    }

    function _doLoadMode(mode) {
        return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/' + mode + '/' + mode + '.min.js');
    }

    function create(elementId, options) {
        options = options || {};
        return load().then(function() {
            if (options.mode) {
                return _doLoadMode(options.mode).then(function() {
                    return _doCreate(elementId, options);
                });
            }
            return _doCreate(elementId, options);
        });
    }

    function _doCreate(elementId, options) {
        var editor = _cm.fromTextArea(document.getElementById(elementId), {
            theme: 'dracula',
            lineNumbers: true
        });
        _editors[elementId] = editor;
        return editor;
    }

    function getValue(elementId) {
        return _editors[elementId] ? _editors[elementId].getValue() : undefined;
    }

    function setValue(elementId, value) {
        if (_editors[elementId]) {
            _editors[elementId].setValue(value);
        }
    }

    return {
        load: load,
        loadMode: loadMode,
        create: create,
        getValue: getValue,
        setValue: setValue
    };

})();


// ==================== Lv00TensorFlowJS - TensorFlow.js 机器学习库 ====================
// GitHub: https://github.com/tensorflow/tfjs
// License: Apache-2.0
// 功能：在浏览器和Node.js中进行机器学习
// 分类：机器学习

var Lv00TensorFlowJS = (function() {
    'use strict';

    var _loaded = false;
    var _tf = null;

    /**
     * 加载TensorFlow.js机器学习库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为tfjs对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_tf);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.17.0/dist/tf.min.js').then(function() {
            _tf = window.tf;
            _loaded = true;
            console.log('[Lv00 TensorFlowJS] TensorFlow.js loaded successfully');
            return _tf;
        });
    }

    function tensor(data, shape) {
        if (!_loaded) { console.error('[Lv00 TensorFlowJS] tensor: library not loaded'); return null; }
        return _tf.tensor(data, shape);
    }

    function createLinearModel() {
        if (!_loaded) { console.error('[Lv00 TensorFlowJS] createLinearModel: library not loaded'); return null; }
        var model = _tf.sequential();
        model.add(_tf.layers.dense({ units: 1, inputShape: [1] }));
        model.compile({ loss: 'meanSquaredError', optimizer: 'sgd' });
        return model;
    }

    function trainModel(model, xs, ys, epochs) {
        if (!_loaded) { console.error('[Lv00 TensorFlowJS] trainModel: library not loaded'); return null; }
        epochs = epochs || 100;
        var xTensor = _tf.tensor(xs);
        var yTensor = _tf.tensor(ys);
        return model.fit(xTensor, yTensor, { epochs: epochs }).then(function() {
            xTensor.dispose();
            yTensor.dispose();
        });
    }

    function predict(model, input) {
        if (!_loaded) { console.error('[Lv00 TensorFlowJS] predict: library not loaded'); return null; }
        var inputTensor = _tf.tensor(input);
        var prediction = model.predict(inputTensor);
        var result = prediction.dataSync();
        inputTensor.dispose();
        prediction.dispose();
        return result;
    }

    return {
        load: load,
        tensor: tensor,
        createLinearModel: createLinearModel,
        trainModel: trainModel,
        predict: predict
    };

})();


// ==================== Lv00TransformersJS - Transformers.js 浏览器端LLM推理 ====================
// GitHub: https://github.com/xenova/transformers.js
// License: Apache-2.0
// 功能：在浏览器中直接运行Hugging Face Transformers模型
// 分类：机器学习

var Lv00TransformersJS = (function() {
    'use strict';

    var _loaded = false;
    var _transformers = null;
    var _pipeline = null;

    /**
     * 加载Transformers.js浏览器端推理库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为transformers库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_transformers);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2').then(function() {
            _transformers = window.Transformers;
            _loaded = true;
            console.log('[Lv00 TransformersJS] Transformers.js loaded successfully');
            return _transformers;
        });
    }

    function createTextGenerationPipeline(model) {
        model = model || 'Xenova/distilgpt2';
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return _transformers.pipeline('text-generation', model).then(function(pipe) {
                _pipeline = pipe;
                return _pipeline;
            });
        });
    }

    function generateText(prompt, maxLength) {
        maxLength = maxLength || 50;
        var p = _pipeline ? Promise.resolve(_pipeline) : createTextGenerationPipeline();
        return p.then(function(pipe) {
            return pipe(prompt, { max_length: maxLength }).then(function(result) {
                return result[0].generated_text;
            });
        });
    }

    function sentimentAnalysis(text) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return _transformers.pipeline('sentiment-analysis').then(function(classifier) {
                return classifier(text);
            });
        });
    }

    function textEmbedding(texts) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return _transformers.pipeline('feature-extraction').then(function(embedder) {
                return embedder(texts, { pooling: 'mean', normalize: true });
            });
        });
    }

    return {
        load: load,
        createTextGenerationPipeline: createTextGenerationPipeline,
        generateText: generateText,
        sentimentAnalysis: sentimentAnalysis,
        textEmbedding: textEmbedding
    };

})();


// ==================== Lv00ONNXRuntime - ONNX Runtime Web 跨平台模型推理 ====================
// GitHub: https://github.com/microsoft/onnxruntime
// License: MIT
// 功能：在浏览器中运行ONNX模型，支持多种深度学习框架导出的模型
// 分类：机器学习

var Lv00ONNXRuntime = (function() {
    'use strict';

    var _loaded = false;
    var _ort = null;
    var _sessions = {};

    /**
     * 加载ONNX Runtime Web推理库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为ort库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_ort);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/onnxruntime-web@1.17.1/dist/ort.min.js').then(function() {
            _ort = window.ort;
            _loaded = true;
            console.log('[Lv00 ONNXRuntime] ONNX Runtime Web loaded successfully');
            return _ort;
        });
    }

    function loadModel(modelName, modelUrl) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return _ort.InferenceSession.create(modelUrl).then(function(session) {
                _sessions[modelName] = session;
                return session;
            });
        });
    }

    function runInference(modelName, inputData) {
        var session = _sessions[modelName];
        if (!session) return Promise.reject(new Error('Model ' + modelName + ' not loaded'));

        var feeds = {};
        var keys = Object.keys(inputData);
        for (var i = 0; i < keys.length; i++) {
            var name = keys[i];
            var data = inputData[name];
            feeds[name] = new _ort.Tensor(data.type || 'float32', data.data, data.dims);
        }

        return session.run(feeds);
    }

    function disposeModel(modelName) {
        if (_sessions[modelName]) {
            _sessions[modelName].release();
            delete _sessions[modelName];
        }
    }

    return {
        load: load,
        loadModel: loadModel,
        runInference: runInference,
        disposeModel: disposeModel
    };

})();


// ==================== Lv00LangChain - LangChain.js 风格 LLM应用框架 ====================
// GitHub: https://github.com/langchain-ai/langchainjs
// License: MIT
// 功能：构建LLM应用的框架（简化版实现）
// 分类：LLM框架

var Lv00LangChain = (function() {
    'use strict';

    /**
     * 初始化LangChain.js风格LLM框架模块（纯JavaScript实现，无需外部依赖）
     * @returns {Promise<void>} 立即resolve的Promise
     */
    function load() {
        return Promise.resolve();
    }

    function createLLMChain(llm, promptTemplate) {
        return {
            llm: llm,
            promptTemplate: promptTemplate,

            run: function(variables) {
                var prompt = this.promptTemplate;
                var keys = Object.keys(variables);
                for (var i = 0; i < keys.length; i++) {
                    prompt = prompt.replace('{' + keys[i] + '}', variables[keys[i]]);
                }
                return this.llm.generate(prompt);
            }
        };
    }

    function createBufferMemory() {
        return {
            messages: [],

            addUserMessage: function(message) {
                this.messages.push({ role: 'user', content: message });
            },

            addAIMessage: function(message) {
                this.messages.push({ role: 'ai', content: message });
            },

            getMessages: function() {
                return this.messages;
            },

            clear: function() {
                this.messages = [];
            }
        };
    }

    function createSimpleRetriever(documents) {
        return {
            documents: documents,

            retrieve: function(query, topK) {
                topK = topK || 3;
                var queryWords = query.toLowerCase().split(/\s+/);
                var self = this;
                var scored = self.documents.map(function(doc) {
                    var content = doc.content.toLowerCase();
                    var score = 0;
                    for (var i = 0; i < queryWords.length; i++) {
                        if (content.indexOf(queryWords[i]) !== -1) score++;
                    }
                    return { doc: doc, score: score };
                });

                return scored
                    .sort(function(a, b) { return b.score - a.score; })
                    .slice(0, topK)
                    .map(function(item) { return item.doc; });
            }
        };
    }
    return {
        load: load,
        createLLMChain: createLLMChain,
        createBufferMemory: createBufferMemory,
        createSimpleRetriever: createSimpleRetriever
    };

})();


// ==================== Lv00Ollama - Ollama.js 本地LLM客户端 ====================
// GitHub: https://github.com/ollama/ollama-js
// License: MIT
// 功能：与本地Ollama服务通信，运行本地大语言模型
// 分类：LLM框架

var Lv00Ollama = (function() {
    'use strict';

    /**
     * 初始化Ollama.js本地LLM客户端模块（纯JavaScript实现，无需外部依赖）
     * @returns {Promise<void>} 立即resolve的Promise
     */
    function load() {
        return Promise.resolve();
    }

    var _baseUrl = 'http://localhost:11434';

    function setBaseUrl(url) {
        _baseUrl = url;
    }

    function listModels() {
        return fetch(_baseUrl + '/api/tags').then(function(response) {
            return response.json();
        });
    }

    function generate(model, prompt, options) {
        options = options || {};
        return fetch(_baseUrl + '/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model,
                prompt: prompt,
                stream: false
            })
        }).then(function(response) {
            return response.json();
        });
    }

    function chat(model, messages, options) {
        options = options || {};
        return fetch(_baseUrl + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model,
                messages: messages,
                stream: false
            })
        }).then(function(response) {
            return response.json();
        });
    }
    return {
        load: load,
        setBaseUrl: setBaseUrl,
        listModels: listModels,
        generate: generate,
        chat: chat
    };

})();


// ==================== Lv00Mermaid - Mermaid.js 流程图/图表渲染 ====================
// GitHub: https://github.com/mermaid-js/mermaid
// License: MIT
// 功能：基于文本的图表渲染，支持流程图、序列图、甘特图等
// 分类：数据可视化

var Lv00Mermaid = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Mermaid.js图表流程图渲染库（从CDN加载并初始化主题配置）
     * @returns {Promise<void>} 加载并初始化完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/mermaid@10.9.0/dist/mermaid.min.js').then(function() {
            window.mermaid.initialize({
                startOnLoad: false,
                theme: 'dark',
                themeVariables: {
                    primaryColor: '#2196f3',
                    primaryTextColor: '#fff',
                    lineColor: '#4caf50',
                    background: '#0a0a0a'
                }
            });
            _loaded = true;
            console.log('[Lv00 Mermaid] Mermaid.js loaded successfully');
        });
    }

    function render(id, definition) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return window.mermaid.render(id, definition).then(function(result) {
                return result.svg;
            }).catch(function(e) {
                console.error('[Lv00 Mermaid] Render error:', e);
                return null;
            });
        });
    }

    function renderToContainer(containerId, definition) {
        var renderId = 'mermaid-' + Date.now();
        return render(renderId, definition).then(function(svg) {
            if (svg) {
                var container = document.getElementById(containerId);
                // 【安全说明】SVG来自Mermaid.js（可信第三方库输出），
                // 使用_safeSetHTML通过DOMParser+importNode方式安全注入，
                // 替代直接innerHTML以避免潜在XSS风险。
                if (container) _safeSetHTML(container, svg);
            }
            return svg;
        });
    }

    return {
        load: load,
        render: render,
        renderToContainer: renderToContainer
    };

})();


// ==================== Lv00Cytoscape - Cytoscape.js 图论可视化 ====================
// 【预留模块】当前未被调用，为未来图论分析可视化功能预留
// GitHub: https://github.com/cytoscape/cytoscape.js
// License: MIT
// 功能：图论分析与可视化，适合展示几何约束图
// 分类：数据可视化

var Lv00Cytoscape = (function() {
    'use strict';

    var _loaded = false;
    var _cy = null;

    /**
     * 加载Cytoscape.js图论可视化库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为cytoscape库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.cytoscape);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/cytoscape@3.28.1/dist/cytoscape.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Cytoscape] Cytoscape.js loaded successfully');
            return window.cytoscape;
        });
    }

    function createGraph(containerId, elements, options) {
        elements = elements || [];
        options = options || {};
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            _cy = window.cytoscape({
                container: document.getElementById(containerId),
                elements: elements,
                style: [
                    {
                        selector: 'node',
                        style: {
                            'background-color': '#2196f3',
                            'label': 'data(label)',
                            'color': '#ccc',
                            'font-size': '10px',
                            'text-valign': 'center',
                            'text-halign': 'center',
                            'width': 30,
                            'height': 30
                        }
                    },
                    {
                        selector: 'edge',
                        style: {
                            'width': 2,
                            'line-color': '#4caf50',
                            'target-arrow-color': '#4caf50',
                            'curve-style': 'bezier'
                        }
                    },
                    {
                        selector: 'node[type="constraint"]',
                        style: { 'background-color': '#ff9800' }
                    },
                    {
                        selector: 'node[type="variable"]',
                        style: { 'background-color': '#9c27b0' }
                    }
                ],
                layout: { name: options.layout || 'cose' }
            });
            return _cy;
        });
    }

    function addNode(id, label, type) {
        type = type || 'default';
        if (_cy) {
            _cy.add({ data: { id: id, label: label, type: type } });
            _cy.layout({ name: 'cose' }).run();
        }
    }

    function addEdge(source, target) {
        if (_cy) {
            _cy.add({ data: { source: source, target: target } });
            _cy.layout({ name: 'cose' }).run();
        }
    }

    function getGraph() {
        return _cy;
    }

    return {
        load: load,
        createGraph: createGraph,
        addNode: addNode,
        addEdge: addEdge,
        getGraph: getGraph
    };

})();


// ==================== Lv00Marked - Marked.js Markdown解析 ====================
// GitHub: https://github.com/markedjs/marked
// License: MIT
// 功能：高性能Markdown解析器
// 分类：文档处理

var Lv00Marked = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Marked.js Markdown解析库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为marked库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.marked);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/marked@12.0.1/marked.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Marked] Marked.js loaded successfully');
            return window.marked;
        });
    }

    function parse(markdown) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return window.marked.parse(markdown);
        });
    }

    function renderTo(containerId, markdown) {
        return parse(markdown).then(function(html) {
            var container = document.getElementById(containerId);
            // 【安全说明】HTML来自Marked.js（可信第三方Markdown解析器输出），
            // 使用_safeSetHTML通过DOMParser+importNode方式安全注入，
            // 替代直接innerHTML以避免潜在XSS风险。
            if (container) _safeSetHTML(container, html);
            return html;
        });
    }

    return {
        load: load,
        parse: parse,
        renderTo: renderTo
    };

})();


// ==================== Lv00JsPDF - jsPDF PDF生成 ====================
// GitHub: https://github.com/parallax/jsPDF
// License: MIT
// 功能：在浏览器中生成PDF文档
// 分类：文档处理

var Lv00JsPDF = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载jsPDF文档生成库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为jspdf对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.jspdf);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 JsPDF] jsPDF loaded successfully');
            return window.jspdf;
        });
    }

    function createDocument(options) {
        options = options || {};
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var jsPDF = window.jspdf.jsPDF;
            return new jsPDF({
                orientation: options.orientation || 'portrait',
                unit: options.unit || 'mm',
                format: options.format || 'a4'
            });
        });
    }

    function generateReport(title, content, filename) {
        filename = filename || 'lv00-report.pdf';
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var jsPDF = window.jspdf.jsPDF;
            var doc = new jsPDF();

            doc.setFont('helvetica');
            doc.setFontSize(18);
            doc.text(title, 20, 20);

            doc.setFontSize(10);
            var lines = doc.splitTextToSize(content, 170);
            doc.text(lines, 20, 35);

            doc.save(filename);
            return doc;
        });
    }

    return {
        load: load,
        createDocument: createDocument,
        generateReport: generateReport
    };

})();


// ==================== Lv00MatterJS - Matter.js 2D物理引擎 ====================
// 【预留模块】当前未被调用，为未来物理仿真功能预留
// GitHub: https://github.com/liabru/matter-js
// License: MIT
// 功能：2D物理模拟引擎，刚体、碰撞、约束
// 分类：物理模拟

var Lv00MatterJS = (function() {
    'use strict';

    var _loaded = false;
    var _engine = null;

    /**
     * 【预留模块】加载Matter.js 2D物理引擎（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为Matter库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.Matter);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/matter-js@0.19.0/build/matter.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 MatterJS] Matter.js loaded successfully');
            return window.Matter;
        });
    }

    function createWorld(containerId, options) {
        options = options || {};
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var M = window.Matter;
            var w = options.width || 400;
            var h = options.height || 300;

            var engine = M.Engine.create();
            var render = M.Render.create({
                element: document.getElementById(containerId),
                engine: engine,
                options: {
                    width: w,
                    height: h,
                    wireframes: false,
                    background: '#0a0a0a'
                }
            });

            var ground = M.Bodies.rectangle(
                w / 2,
                h - 10,
                w,
                20,
                { isStatic: true, render: { fillStyle: '#333' } }
            );
            M.Composite.add(engine.world, ground);

            _engine = engine;
            M.Render.run(render);
            M.Runner.run(M.Runner.create(), engine);

            return { engine: engine, render: render };
        });
    }

    function addBody(type, x, y, options) {
        if (!_loaded || !_engine) return;
        options = options || {};
        var M = window.Matter;
        var body;

        switch (type) {
            case 'circle':
                body = M.Bodies.circle(x, y, options.radius || 20, options);
                break;
            case 'rectangle':
                body = M.Bodies.rectangle(x, y, options.width || 40, options.height || 40, options);
                break;
            case 'polygon':
                body = M.Bodies.polygon(x, y, options.sides || 6, options.radius || 20, options);
                break;
            default:
                body = M.Bodies.circle(x, y, 20, options);
        }

        M.Composite.add(_engine.world, body);
        return body;
    }

    return {
        load: load,
        createWorld: createWorld,
        addBody: addBody
    };

})();


// ==================== Lv00DayJS - Day.js 轻量日期处理 ====================
// GitHub: https://github.com/iamkun/dayjs
// License: MIT
// 功能：轻量级日期处理库，moment.js替代品
// 分类：工具库

var Lv00DayJS = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Day.js轻量日期处理库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为dayjs库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.dayjs);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/dayjs@1.11.10/dayjs.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 DayJS] Day.js loaded successfully');
            return window.dayjs;
        });
    }

    function now(format) {
        format = format || 'YYYY-MM-DD HH:mm:ss';
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return window.dayjs().format(format);
        });
    }

    function format(date, formatStr) {
        formatStr = formatStr || 'YYYY-MM-DD HH:mm:ss';
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return window.dayjs(date).format(formatStr);
        });
    }

    return {
        load: load,
        now: now,
        format: format
    };

})();


// ==================== Lv00FileSaver - FileSaver.js 文件保存 ====================
// GitHub: https://github.com/nicolo-ribaudo/FileSaver.js
// License: MIT
// 功能：在浏览器中保存文件
// 分类：工具库

var Lv00FileSaver = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载FileSaver.js文件保存库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/file-saver@2.0.5/dist/FileSaver.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 FileSaver] FileSaver.js loaded successfully');
        });
    }

    function saveText(content, filename) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
            window.saveAs(blob, filename);
        });
    }

    function saveJSON(data, filename) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
            window.saveAs(blob, filename);
        });
    }

    function saveBlob(blob, filename) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            window.saveAs(blob, filename);
        });
    }

    return {
        load: load,
        saveText: saveText,
        saveJSON: saveJSON,
        saveBlob: saveBlob
    };

})();


// ==================== Lv00Anime - Anime.js 动画引擎 ====================
// 【预留模块】当前未被调用，为未来动画增强功能预留
// GitHub: https://github.com/juliangarnier/anime
// License: MIT
// 功能：轻量级动画引擎，支持CSS/SVG/DOM/JS对象动画
// 分类：动画引擎

var Lv00Anime = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 【预留模块】加载Anime.js动画引擎（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为anime库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(window.anime);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Anime] Anime.js loaded successfully');
            return window.anime;
        });
    }

    function animate(selector, properties, options) {
        options = options || {};
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var params = { targets: selector };
            var key;
            for (key in properties) {
                if (properties.hasOwnProperty(key)) {
                    params[key] = properties[key];
                }
            }
            params.duration = options.duration || 1000;
            params.easing = options.easing || 'easeInOutQuad';
            for (key in options) {
                if (options.hasOwnProperty(key) && key !== 'duration' && key !== 'easing') {
                    params[key] = options[key];
                }
            }
            return window.anime(params);
        });
    }

    function createTimeline(options) {
        if (!_loaded) return null;
        options = options || {};
        return window.anime.timeline({
            duration: options.duration || 1000,
            easing: options.easing || 'easeInOutQuad'
        });
    }

    function pulse(selector) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            return window.anime({
                targets: selector,
                scale: [1, 1.3, 1],
                opacity: [1, 0.7, 1],
                duration: 600,
                easing: 'easeInOutQuad'
            });
        });
    }

    return {
        load: load,
        animate: animate,
        createTimeline: createTimeline,
        pulse: pulse
    };

})();


// ==================== Lv00XTerm - xterm.js 终端模拟器 ====================
// 【预留模块】当前未被调用，为未来Web终端功能预留
// GitHub: https://github.com/xtermjs/xterm.js
// License: MIT
// 功能：浏览器端终端模拟器，支持WebSocket连接
// 分类：终端模拟

var Lv00XTerm = (function() {
    'use strict';

    var _loaded = false;
    var _terminals = {};

    function _loadCSS(href, integrity) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.crossOrigin = 'anonymous';
        if (integrity) {
            link.integrity = integrity;
        }
        document.head.appendChild(link);
    }

    /**
     * 【预留模块】加载xterm.js终端模拟器（CSS+JS，从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为Terminal构造函数
     */
    function load() {
        if (_loaded) return Promise.resolve(window.Terminal);

        _loadCSS('https://cdn.jsdelivr.net/npm/@xterm/xterm@5.4.0/css/xterm.css', 'sha384-8Xk9wy/gzEDUKrXtrmCFa2bBuK3BpjpDuL/p0SeKQX19Khl/M+lHOgD/CyYf7efP');

return _lvLoadScript('https://cdn.jsdelivr.net/npm/@xterm/xterm@5.4.0/lib/xterm.js').then(function() {
            _loaded = true;
            console.log('[Lv00 XTerm] xterm.js loaded successfully');
            return window.Terminal;
        });
    }

    function createTerminal(elementId, options) {
        options = options || {};
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var terminal = new window.Terminal({
                theme: {
                    background: '#0a0a0a',
                    foreground: '#cccccc',
                    cursor: '#4caf50',
                    selectionBackground: '#2196f3'
                },
                fontSize: 12,
                fontFamily: 'Consolas, "Courier New", monospace',
                cursorBlink: true
            });

            terminal.open(document.getElementById(elementId));
            _terminals[elementId] = terminal;
            return terminal;
        });
    }

    function write(elementId, text) {
        if (_terminals[elementId]) {
            _terminals[elementId].write(text);
        }
    }

    function writeLine(elementId, text, color) {
        color = color || '\x1b[37m';
        if (_terminals[elementId]) {
            _terminals[elementId].writeln(color + text + '\x1b[0m');
        }
    }

    return {
        load: load,
        createTerminal: createTerminal,
        write: write,
        writeLine: writeLine
    };

})();




// ==================== Lv00Clipboard - Clipboard.js 剪贴板操作 ====================
// GitHub: https://github.com/zenorocha/clipboard.js
// License: MIT
// 功能：现代浏览器剪贴板复制操作
// 分类：工具库
var Lv00Clipboard = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Clipboard.js剪贴板操作库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/clipboard@2.0.11/dist/clipboard.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Clipboard] Clipboard.js loaded successfully');
        });
    }

    function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text).then(function() {
                console.log('[Lv00 Clipboard] Text copied to clipboard');
                return true;
            }).catch(function(err) {
                console.error('[Lv00 Clipboard] Clipboard write failed:', err);
                return _fallbackCopy(text);
            });
        }
        return _fallbackCopy(text);
    }

    function _fallbackCopy(text) {
        var textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        textArea.style.top = '-9999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            var success = document.execCommand('copy');
            console.log('[Lv00 Clipboard] Fallback copy ' + (success ? 'succeeded' : 'failed'));
            return Promise.resolve(success);
        } catch (err) {
            console.error('[Lv00 Clipboard] Fallback copy error:', err);
            return Promise.resolve(false);
        } finally {
            document.body.removeChild(textArea);
        }
    }

    return {
        load: load,
        copyText: copyText
    };

})();


// ==================== Lv00Delaunator - Delaunator 德劳内三角剖分 ====================
// GitHub: https://github.com/mapbox/delaunator
// License: ISC
// 功能：超快速2D德劳内三角剖分
// 分类：几何算法
var Lv00Delaunator = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Delaunator德劳内三角剖分库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/delaunator@5.0.0/delaunator.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Delaunator] Delaunator loaded successfully');
        });
    }

    function triangulate(points) {
        if (!_loaded || typeof Delaunator === 'undefined') {
            console.warn('[Lv00 Delaunator] Delaunator not loaded');
            return { triangles: [], triangleCoords: [], hull: [] };
        }

        var d = new Delaunator(points);
        var len = d.triangles.length;

        // Build triangles array [[i0,i1,i2], ...]
        var triangles = [];
        for (var i = 0; i < len; i += 3) {
            triangles.push([d.triangles[i], d.triangles[i + 1], d.triangles[i + 2]]);
        }

        // Build triangleCoords: for each triangle, return [[x1,y1], [x2,y2], [x3,y3]]
        var triangleCoords = [];
        for (i = 0; i < len; i += 3) {
            var i0 = d.triangles[i];
            var i1 = d.triangles[i + 1];
            var i2 = d.triangles[i + 2];
            triangleCoords.push([
                [points[i0], points[i0 + 1]],
                [points[i1], points[i1 + 1]],
                [points[i2], points[i2 + 1]]
            ]);
        }

        // Build hull as array of [x,y] points
        var hull = [];
        for (i = 0; i < d.hull.length; i++) {
            var idx = d.hull[i];
            hull.push([points[idx * 2], points[idx * 2 + 1]]);
        }

        return {
            triangles: triangles,
            triangleCoords: triangleCoords,
            hull: hull
        };
    }

    return {
        load: load,
        triangulate: triangulate
    };

})();


// ==================== Lv00Turndown - Turndown HTML转Markdown ====================
// GitHub: https://github.com/mixmark-io/turndown
// License: MIT
// 功能：将HTML转换为Markdown
// 分类：文档处理

var Lv00Turndown = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载Turndown HTML转Markdown库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/turndown@7.1.3/dist/turndown.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Turndown] Turndown loaded successfully');
        });
    }

    function convert(html) {
        var p = _loaded ? Promise.resolve() : load();
        return p.then(function() {
            var turndownService = new window.TurndownService({
                headingStyle: 'atx',
                codeBlockStyle: 'fenced'
            });
            return turndownService.turndown(html);
        });
    }

    return {
        load: load,
        convert: convert
    };

})();


// ==================== Lv00ThreeJS - Three.js 3D图形引擎 ====================
// 【预留模块】当前未被调用，为未来3D可视化功能预留
// GitHub: https://github.com/mrdoob/three.js
// License: MIT
// 功能：基于WebGL的3D图形渲染引擎
// 分类：图形绘制

var Lv00ThreeJS = (function() {
    'use strict';

    var _loaded = false;
    var _THREE = null;

    /**
     * 【预留模块】加载Three.js 3D图形引擎（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为THREE库对象
     */
    function load() {
        if (_loaded) return Promise.resolve(_THREE);

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js').then(function() {
            _THREE = window.THREE;
            _loaded = true;
            console.log('[Lv00 ThreeJS] Three.js loaded successfully');
            return _THREE;
        });
    }

    function createScene(containerId, options) {
        options = options || {};
        var container = document.getElementById(containerId);
        if (!container) return null;

        var scene = new _THREE.Scene();
        scene.background = new _THREE.Color(options.backgroundColor || 0x0a0a0a);

        var camera = new _THREE.PerspectiveCamera(
            options.fov || 75,
            container.clientWidth / container.clientHeight,
            0.1,
            1000
        );

        var renderer = new _THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(container.clientWidth, container.clientHeight);
        container.appendChild(renderer.domElement);

        camera.position.z = options.cameraZ || 5;

        return { scene: scene, camera: camera, renderer: renderer };
    }

    function createCube(scene, options) {
        options = options || {};
        var geometry = new _THREE.BoxGeometry(
            options.width || 1,
            options.height || 1,
            options.depth || 1
        );
        var material = new _THREE.MeshBasicMaterial({
            color: options.color || 0x2196f3,
            wireframe: options.wireframe !== false
        });
        var cube = new _THREE.Mesh(geometry, material);
        scene.add(cube);
        return cube;
    }

    function createSphere(scene, options) {
        options = options || {};
        var geometry = new _THREE.SphereGeometry(
            options.radius || 0.5,
            options.widthSegments || 32,
            options.heightSegments || 16
        );
        var material = new _THREE.MeshBasicMaterial({
            color: options.color || 0x4caf50,
            wireframe: options.wireframe !== false
        });
        var sphere = new _THREE.Mesh(geometry, material);
        scene.add(sphere);
        return sphere;
    }

    function animate(renderer, scene, camera, objects, onUpdate) {
        function render() {
            requestAnimationFrame(render);
            if (onUpdate) onUpdate(objects);
            renderer.render(scene, camera);
        }
        render();
    }

    return {
        load: load,
        createScene: createScene,
        createCube: createCube,
        createSphere: createSphere,
        animate: animate
    };

})();





// ==================== Lv00Fuse - Fuse.js 模糊搜索 ====================
// GitHub: https://github.com/krisk/Fuse
// License: Apache-2.0
// 功能：轻量级模糊搜索库
// 分类：工具库

var Lv00Fuse = (function() {
    'use strict';

    var _loaded = false;
    var _Fuse = null;

    /**
     * 加载Fuse.js模糊搜索库（从CDN加载并缓存）
     * @returns {Promise<Object>} 加载完成后resolve为Fuse构造函数
     */
    function load() {
        if (_loaded) return Promise.resolve(_Fuse);

return _lvLoadScript('https://cdn.jsdelivr.net/npm/fuse.js@7.0.0/dist/fuse.min.js').then(function() {
            _Fuse = window.Fuse;
            _loaded = true;
            console.log('[Lv00 Fuse] Fuse.js loaded successfully');
            return _Fuse;
        });
    }

    function createIndex(list, options) {
        options = options || {};
        var fuseOptions = {
            keys: options.keys || [],
            threshold: options.threshold || 0.4,
            includeScore: options.includeScore || false
        };
        return new _Fuse(list, fuseOptions);
    }

    function search(index, query, limit) {
        limit = limit || 10;
        return index.search(query).slice(0, limit);
    }

    function createAndSearch(list, query, options) {
        var index = createIndex(list, options);
        return search(index, query, options.limit);
    }

    return {
        load: load,
        createIndex: createIndex,
        search: search,
        createAndSearch: createAndSearch
    };

})();


// ==================== Lv00UUID - UUID 唯一标识符生成 ====================
// GitHub: https://github.com/uuidjs/uuid
// License: MIT
// 功能：RFC4122标准UUID生成器
// 分类：工具库

var Lv00UUID = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载UUID唯一标识符生成库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/uuid/8.3.2/uuidv4.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 UUID] UUID loaded successfully');
        });
    }

    function v4() {
        if (typeof uuidv4 !== 'undefined') {
            return uuidv4();
        }
        // 降级方案
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0;
            var v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    function v4Short() {
        return v4().replace(/-/g, '').substring(0, 16);
    }

    return {
        load: load,
        v4: v4,
        v4Short: v4Short
    };

})();




// ==================== Lv00Crypto - CryptoJS 加密与哈希 ====================
// GitHub: https://github.com/brix/crypto-js
// License: MIT
// 功能：JavaScript加密库，支持MD5/SHA256/AES/DES等
// 分类：加密哈希

var Lv00Crypto = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载CryptoJS加密哈希库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.2.0/crypto-js.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Crypto] CryptoJS loaded successfully');
        });
    }

    function md5(data) {
        if (!_loaded) return null;
        return window.CryptoJS.MD5(data).toString();
    }

    function sha256(data) {
        if (!_loaded) return null;
        return window.CryptoJS.SHA256(data).toString();
    }

    function sha1(data) {
        if (!_loaded) return null;
        return window.CryptoJS.SHA1(data).toString();
    }

    function hmacSha256(data, key) {
        if (!_loaded) return null;
        return window.CryptoJS.HmacSHA256(data, key).toString();
    }

    function encryptAES(data, passphrase) {
        if (!_loaded) return null;
        return window.CryptoJS.AES.encrypt(data, passphrase).toString();
    }

    function decryptAES(encrypted, passphrase) {
        if (!_loaded) return null;
        var bytes = window.CryptoJS.AES.decrypt(encrypted, passphrase);
        return bytes.toString(window.CryptoJS.enc.Utf8);
    }

    function base64Encode(data) {
        if (!_loaded) return null;
        return window.CryptoJS.enc.Base64.stringify(window.CryptoJS.enc.Utf8.parse(data));
    }

    function base64Decode(encoded) {
        if (!_loaded) return null;
        return window.CryptoJS.enc.Base64.parse(encoded).toString(window.CryptoJS.enc.Utf8);
    }

    return {
        load: load,
        md5: md5,
        sha256: sha256,
        sha1: sha1,
        hmacSha256: hmacSha256,
        encryptAES: encryptAES,
        decryptAES: decryptAES,
        base64Encode: base64Encode,
        base64Decode: base64Decode
    };

})();


// ==================== Lv00SeedRandom - seedrandom 种子随机数 ====================
// GitHub: https://github.com/davidbau/seedrandom
// License: MIT
// 功能：可复现的种子随机数生成器
// 分类：加密哈希

var Lv00SeedRandom = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载seedrandom种子随机数生成库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/seedrandom@3.0.5/seedrandom.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 SeedRandom] seedrandom loaded successfully');
        });
    }

    function createRNG(seed) {
        if (!_loaded || typeof seedrandom === 'undefined') {
            // 降级方案：简单LCG
            var s = typeof seed === 'number' ? seed : (seed || '').split('').reduce(function(a, c) { return a + c.charCodeAt(0); }, 0);
            return function() {
                s = (s * 1664525 + 1013904223) % 4294967296;
                return s / 4294967296;
            };
        }
        return new seedrandom(seed);
    }

    function randomFloat(rng, min, max) {
        min = min !== undefined ? min : 0;
        max = max !== undefined ? max : 1;
        return min + rng() * (max - min);
    }

    function randomInt(rng, min, max) {
        min = Math.ceil(min || 0);
        max = Math.floor(max || 100);
        return Math.floor(min + rng() * (max - min + 1));
    }

    function shuffle(rng, array) {
        var arr = array.slice();
        for (var i = arr.length - 1; i > 0; i--) {
            var j = Math.floor(rng() * (i + 1));
            var temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
        return arr;
    }

    return {
        load: load,
        createRNG: createRNG,
        randomFloat: randomFloat,
        randomInt: randomInt,
        shuffle: shuffle
    };

})();


// ==================== Lv00Pako - pako.js 数据压缩 ====================
// GitHub: https://github.com/nodeca/pako
// License: MIT
// 功能：JavaScript zlib实现，支持deflate/gzip/zlib格式
// 分类：数据压缩

var Lv00Pako = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载pako.js数据压缩/解压库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/pako@2.1.0/dist/pako.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Pako] pako.js loaded successfully');
        });
    }

    function deflate(data) {
        if (!_loaded || typeof pako === 'undefined') return null;
        return window.pako.deflate(data);
    }

    function inflate(compressed) {
        if (!_loaded || typeof pako === 'undefined') return null;
        return window.pako.inflate(compressed);
    }

    function gzip(data) {
        if (!_loaded || typeof pako === 'undefined') return null;
        return window.pako.gzip(data);
    }

    function ungzip(compressed) {
        if (!_loaded || typeof pako === 'undefined') return null;
        return window.pako.ungzip(compressed);
    }

    function deflateToBase64(data) {
        var compressed = deflate(data);
        if (!compressed) return null;
        var binary = '';
        for (var i = 0; i < compressed.length; i++) {
            binary += String.fromCharCode(compressed[i]);
        }
        return btoa(binary);
    }

    function inflateFromBase64(base64Str) {
        var binary = atob(base64Str);
        var bytes = new Uint8Array(binary.length);
        for (var i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return inflate(bytes);
    }

    return {
        load: load,
        deflate: deflate,
        inflate: inflate,
        gzip: gzip,
        ungzip: ungzip,
        deflateToBase64: deflateToBase64,
        inflateFromBase64: inflateFromBase64
    };

})();


// ==================== Lv00TinyQueue - tinyqueue 二叉堆 ====================
// GitHub: https://github.com/mourner/tinyqueue
// License: ISC
// 功能：轻量级二叉堆优先队列
// 分类：数据结构

var Lv00TinyQueue = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载tinyqueue二叉堆优先队列库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/tinyqueue@3.0.0/index.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 TinyQueue] tinyqueue loaded successfully');
        });
    }

    function create(compareFunc) {
        if (!_loaded || typeof TinyQueue === 'undefined') {
            // 降级方案：最小堆
            var heap = [];
            function _siftUp(idx) {
                while (idx > 0) {
                    var parent = (idx - 1) >> 1;
                    var cmp = compareFunc ? compareFunc(heap[idx], heap[parent]) : heap[idx] - heap[parent];
                    if (cmp >= 0) break;
                    var tmp = heap[idx]; heap[idx] = heap[parent]; heap[parent] = tmp;
                    idx = parent;
                }
            }
            function _siftDown(idx) {
                var n = heap.length;
                while (true) {
                    var left = 2 * idx + 1, right = 2 * idx + 2, smallest = idx;
                    if (left < n) {
                        var cmpL = compareFunc ? compareFunc(heap[left], heap[smallest]) : heap[left] - heap[smallest];
                        if (cmpL < 0) smallest = left;
                    }
                    if (right < n) {
                        var cmpR = compareFunc ? compareFunc(heap[right], heap[smallest]) : heap[right] - heap[smallest];
                        if (cmpR < 0) smallest = right;
                    }
                    if (smallest === idx) break;
                    var tmp = heap[idx]; heap[idx] = heap[smallest]; heap[smallest] = tmp;
                    idx = smallest;
                }
            }
            return {
                push: function(item) { heap.push(item); _siftUp(heap.length - 1); },
                pop: function() { if (heap.length === 0) return; var top = heap[0]; var last = heap.pop(); if (heap.length > 0) { heap[0] = last; _siftDown(0); } return top; },
                peek: function() { return heap[0]; },
                get length() { return heap.length; }
            };
        }
        return new TinyQueue([], compareFunc);
    }

    return {
        load: load,
        create: create
    };

})();


// ==================== Lv00RBush - rbush R-tree空间索引 ====================
// GitHub: https://github.com/mourner/rbush
// License: MIT
// 功能：高性能R-tree空间索引，支持矩形插入/搜索/碰撞检测
// 分类：数据结构

var Lv00RBush = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载rbush R-tree空间索引库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/rbush@3.0.1/rbush.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 RBush] rbush loaded successfully');
        });
    }

    function create(maxEntries) {
        if (!_loaded || typeof rbush === 'undefined') return null;
        return new rbush(maxEntries || 9);
    }

    function insert(tree, item) {
        if (!tree) return null;
        return tree.insert(item);
    }

    function loadItems(tree, items) {
        if (!tree) return;
        tree.load(items);
    }

    function search(tree, bbox) {
        if (!tree) return [];
        return tree.search(bbox);
    }

    function collides(tree, bbox) {
        if (!tree) return false;
        return tree.collides(bbox);
    }

    function all(tree) {
        if (!tree) return [];
        return tree.all();
    }

    function remove(tree, item) {
        if (!tree) return null;
        return tree.remove(item);
    }

    return {
        load: load,
        create: create,
        insert: insert,
        loadItems: loadItems,
        search: search,
        collides: collides,
        all: all,
        remove: remove
    };

})();


// ==================== Lv00SimpleStats - simple-statistics 统计库 ====================
// GitHub: https://github.com/simple-statistics/simple-statistics
// License: ISC
// 功能：零依赖JavaScript统计库
// 分类：统计计算

var Lv00SimpleStats = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载simple-statistics统计库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/simple-statistics@7.8.3/dist/simple-statistics.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 SimpleStats] simple-statistics loaded successfully');
        });
    }

    function mean(data) {
        if (!_loaded || typeof ss === 'undefined') {
            var sum = 0;
            for (var i = 0; i < data.length; i++) sum += data[i];
            return sum / data.length;
        }
        return window.ss.mean(data);
    }

    function median(data) {
        if (!_loaded || typeof ss === 'undefined') {
            var sorted = data.slice().sort(function(a, b) { return a - b; });
            var mid = Math.floor(sorted.length / 2);
            return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
        }
        return window.ss.median(data);
    }

    function standardDeviation(data) {
        if (!_loaded || typeof ss === 'undefined') return null;
        return window.ss.standardDeviation(data);
    }

    function linearRegression(data) {
        if (!_loaded || typeof ss === 'undefined') return null;
        return window.ss.linearRegression(data);
    }

    function linearRegressionLine(mb) {
        if (!_loaded || typeof ss === 'undefined') return null;
        return window.ss.linearRegressionLine(mb);
    }

    function quantile(data, q) {
        if (!_loaded || typeof ss === 'undefined') return null;
        return window.ss.quantile(data, q);
    }

    function min(data) {
        if (!_loaded || typeof ss === 'undefined') return Math.min.apply(null, data);
        return window.ss.min(data);
    }

    function max(data) {
        if (!_loaded || typeof ss === 'undefined') return Math.max.apply(null, data);
        return window.ss.max(data);
    }

    function sum(data) {
        if (!_loaded || typeof ss === 'undefined') {
            var s = 0;
            for (var i = 0; i < data.length; i++) s += data[i];
            return s;
        }
        return window.ss.sum(data);
    }

    return {
        load: load,
        mean: mean,
        median: median,
        standardDeviation: standardDeviation,
        linearRegression: linearRegression,
        linearRegressionLine: linearRegressionLine,
        quantile: quantile,
        min: min,
        max: max,
        sum: sum
    };

})();


// ==================== Lv00Earcut - earcut 多边形三角剖分 ====================
// GitHub: https://github.com/mapbox/earcut
// License: ISC
// 功能：高性能多边形耳切法三角剖分
// 分类：几何算法

var Lv00Earcut = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载earcut多边形三角剖分库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/earcut@2.2.4/dist/earcut.min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 Earcut] earcut loaded successfully');
        });
    }

    function triangulate(vertices, holes, dim) {
        if (!_loaded || typeof earcut === 'undefined') return [];
        holes = holes || [];
        dim = dim || 2;
        var indices = window.earcut(vertices, holes, dim);
        var triangles = [];
        for (var i = 0; i < indices.length; i += 3) {
            triangles.push([indices[i], indices[i + 1], indices[i + 2]]);
        }
        return triangles;
    }

    function flatten(polygon) {
        // polygon: [[x1,y1], [x2,y2], ...]
        if (!_loaded || typeof earcut === 'undefined') return null;
        return window.earcut.flatten(polygon);
    }

    return {
        load: load,
        triangulate: triangulate,
        flatten: flatten
    };

})();


// ==================== Lv00RobustPredicates - robust-predicates 精确几何谓词 ====================
// GitHub: https://github.com/mourner/robust-predicates
// License: Unlicense
// 功能：浮点误差鲁棒的几何谓词计算
// 分类：几何算法

var Lv00RobustPredicates = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载robust-predicates精确几何谓词库（两个CDN脚本先后加载并缓存）
     * @returns {Promise<void>} 全部加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/robust-predicates@3.0.2/umd/orient2d.min.js').then(function() {
            // 接着加载incircle
            return _lvLoadScript('https://cdn.jsdelivr.net/npm/robust-predicates@3.0.2/umd/incircle.min.js');
        }).then(function() {
            _loaded = true;
            console.log('[Lv00 RobustPredicates] robust-predicates loaded successfully');
        });
    }

    function orient2d(ax, ay, bx, by, cx, cy) {
        if (!_loaded || typeof orient2d === 'undefined') {
            // 降级方案：叉积
            return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
        }
        return window.orient2d(ax, ay, bx, by, cx, cy);
    }

    function incircle(ax, ay, bx, by, cx, cy, dx, dy) {
        if (!_loaded || typeof incircle === 'undefined') return null;
        return window.incircle(ax, ay, bx, by, cx, cy, dx, dy);
    }

    return {
        load: load,
        orient2d: orient2d,
        incircle: incircle
    };

})();


// ==================== Lv00GLMatrix - gl-matrix 向量矩阵库 ====================
// GitHub: https://github.com/toji/gl-matrix
// License: MIT
// 功能：高性能vec2/vec3/mat4运算，WebGL几何变换专用
// 分类：线性代数

var Lv00GLMatrix = (function() {
    'use strict';

    var _loaded = false;

    /**
     * 加载gl-matrix向量矩阵运算库（从CDN加载并缓存）
     * @returns {Promise<void>} 加载完成后resolve
     */
    function load() {
        if (_loaded) return Promise.resolve();

return _lvLoadScript('https://cdn.jsdelivr.net/npm/gl-matrix@3.4.3/gl-matrix-min.js').then(function() {
            _loaded = true;
            console.log('[Lv00 GLMatrix] gl-matrix loaded successfully');
        });
    }

    // vec2 操作
    function vec2Create(x, y) {
        var v = !_loaded || typeof glMatrix === 'undefined'
            ? new Float32Array(2) : window.glMatrix.vec2.create();
        v[0] = x || 0; v[1] = y || 0;
        return v;
    }

    function vec2Length(v) {
        if (typeof glMatrix !== 'undefined') return window.glMatrix.vec2.length(v);
        return Math.sqrt(v[0] * v[0] + v[1] * v[1]);
    }

    function vec2Distance(a, b) {
        if (typeof glMatrix !== 'undefined') return window.glMatrix.vec2.distance(a, b);
        var dx = a[0] - b[0], dy = a[1] - b[1];
        return Math.sqrt(dx * dx + dy * dy);
    }

    function vec2Dot(a, b) {
        if (typeof glMatrix !== 'undefined') return window.glMatrix.vec2.dot(a, b);
        return a[0] * b[0] + a[1] * b[1];
    }

    function vec2Cross(a, b) {
        // 2D叉积 = 标量
        if (typeof glMatrix !== 'undefined' && window.glMatrix.vec2.cross) {
            var r = window.glMatrix.vec2.cross([], a, b);
            return r[2] || (a[0] * b[1] - a[1] * b[0]);
        }
        return a[0] * b[1] - a[1] * b[0];
    }

    function vec2Normalize(v) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.vec2.create();
            return window.glMatrix.vec2.normalize(r, v);
        }
        var len = vec2Length(v);
        return [v[0] / len, v[1] / len];
    }

    function vec2Add(a, b) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.vec2.create();
            return window.glMatrix.vec2.add(r, a, b);
        }
        return [a[0] + b[0], a[1] + b[1]];
    }

    function vec2Sub(a, b) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.vec2.create();
            return window.glMatrix.vec2.subtract(r, a, b);
        }
        return [a[0] - b[0], a[1] - b[1]];
    }

    function vec2Scale(v, s) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.vec2.create();
            return window.glMatrix.vec2.scale(r, v, s);
        }
        return [v[0] * s, v[1] * s];
    }

    function vec2Angle(a, b) {
        // a与b之间的夹角（弧度）
        var dot = vec2Dot(a, b);
        var cross = vec2Cross(a, b);
        return Math.atan2(cross, dot);
    }

    // mat3 2D变换
    function mat3Create() {
        if (typeof glMatrix !== 'undefined') return window.glMatrix.mat3.create();
        return [1, 0, 0, 0, 1, 0, 0, 0, 1];
    }

    function mat3Translate(m, tx, ty) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.mat3.create();
            return window.glMatrix.mat3.translate(r, m, [tx, ty]);
        }
        m[6] += m[0] * tx + m[3] * ty;
        m[7] += m[1] * tx + m[4] * ty;
        return m;
    }

    function mat3Rotate(m, rad) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.mat3.create();
            return window.glMatrix.mat3.rotate(r, m, rad);
        }
        var cos = Math.cos(rad), sin = Math.sin(rad);
        var a0 = m[0], a1 = m[1], a3 = m[3], a4 = m[4];
        m[0] = a0 * cos + a3 * sin;
        m[1] = a1 * cos + a4 * sin;
        m[3] = a3 * cos - a0 * sin;
        m[4] = a4 * cos - a1 * sin;
        return m;
    }

    function mat3Scale(m, sx, sy) {
        if (typeof glMatrix !== 'undefined') {
            var r = window.glMatrix.mat3.create();
            return window.glMatrix.mat3.scale(r, m, [sx, sy]);
        }
        m[0] *= sx; m[1] *= sx;
        m[3] *= sy; m[4] *= sy;
        return m;
    }

    function transformPoint(mat, x, y) {
        // 2D仿射变换
        return {
            x: mat[0] * x + mat[3] * y + mat[6],
            y: mat[1] * x + mat[4] * y + mat[7]
        };
    }

    return {
        load: load,
        vec2Create: vec2Create,
        vec2Length: vec2Length,
        vec2Distance: vec2Distance,
        vec2Dot: vec2Dot,
        vec2Cross: vec2Cross,
        vec2Normalize: vec2Normalize,
        vec2Add: vec2Add,
        vec2Sub: vec2Sub,
        vec2Scale: vec2Scale,
        vec2Angle: vec2Angle,
        mat3Create: mat3Create,
        mat3Translate: mat3Translate,
        mat3Rotate: mat3Rotate,
        mat3Scale: mat3Scale,
        transformPoint: transformPoint
    };

})();


// ==================== Lv00Libraries - 集成管理器 ====================
// 统一管理所有38个开源库的加载、初始化和调用
// 提供便捷的高层API用于几何计算、数据可视化、文档导出等场景

var Lv00Libraries = {
    mathJS: Lv00MathJS,
    highlightJS: Lv00HighlightJS,
    fabricJS: Lv00FabricJS,
    store: Lv00Store,
    d3: Lv00D3,
    echarts: Lv00ECharts,
    lodash: Lv00Lodash,
    axios: Lv00Axios,
    codeMirror: Lv00CodeMirror,
    tensorflowJS: Lv00TensorFlowJS,
    transformersJS: Lv00TransformersJS,
    onnxRuntime: Lv00ONNXRuntime,
    langChain: Lv00LangChain,
    ollama: Lv00Ollama,
    mermaid: Lv00Mermaid,
    cytoscape: Lv00Cytoscape,
    marked: Lv00Marked,
    jsPDF: Lv00JsPDF,
    matterJS: Lv00MatterJS,
    dayJS: Lv00DayJS,
    fileSaver: Lv00FileSaver,
    anime: Lv00Anime,
    xterm: Lv00XTerm,
    clipboard: Lv00Clipboard,
    delaunator: Lv00Delaunator,
    turndown: Lv00Turndown,
    threeJS: Lv00ThreeJS,
    fuse: Lv00Fuse,
    uuid: Lv00UUID,
    crypto: Lv00Crypto,
    seedRandom: Lv00SeedRandom,
    pako: Lv00Pako,
    tinyQueue: Lv00TinyQueue,
    rbush: Lv00RBush,
    simpleStats: Lv00SimpleStats,
    earcut: Lv00Earcut,
    robustPredicates: Lv00RobustPredicates,
    glMatrix: Lv00GLMatrix,

    // 初始化所有已注册的集成库（并行加载，单个失败不影响整体）
    initAll: function() {
        console.log('[Lv00 Lib] Initializing all integrations...');

        return Promise.all([
            this.store.load().catch(function(e) { console.warn('[Lv00 Lib] Store failed:', e); }),
            this.langChain.load().catch(function(e) { console.warn('[Lv00 Lib] LangChain failed:', e); }),
            this.ollama.load().catch(function(e) { console.warn('[Lv00 Lib] Ollama failed:', e); }),
            this.mathJS.load().catch(function(e) { console.warn('[Lv00 Lib] Math.js failed:', e); }),
            this.highlightJS.load().catch(function(e) { console.warn('[Lv00 Lib] Highlight.js failed:', e); }),
            this.fabricJS.load().catch(function(e) { console.warn('[Lv00 Lib] Fabric.js failed:', e); }),
            this.d3.load().catch(function(e) { console.warn('[Lv00 Lib] D3.js failed:', e); }),
            this.echarts.load().catch(function(e) { console.warn('[Lv00 Lib] ECharts failed:', e); }),
            this.lodash.load().catch(function(e) { console.warn('[Lv00 Lib] Lodash failed:', e); }),
            this.axios.load().catch(function(e) { console.warn('[Lv00 Lib] Axios failed:', e); }),
            this.codeMirror.load().catch(function(e) { console.warn('[Lv00 Lib] CodeMirror failed:', e); }),
            this.tensorflowJS.load().catch(function(e) { console.warn('[Lv00 Lib] TensorFlow.js failed:', e); }),
            this.transformersJS.load().catch(function(e) { console.warn('[Lv00 Lib] Transformers.js failed:', e); }),
            this.onnxRuntime.load().catch(function(e) { console.warn('[Lv00 Lib] ONNX Runtime failed:', e); }),
            this.mermaid.load().catch(function(e) { console.warn('[Lv00 Lib] Mermaid.js failed:', e); }),
            this.cytoscape.load().catch(function(e) { console.warn('[Lv00 Lib] Cytoscape.js failed:', e); }),
            this.marked.load().catch(function(e) { console.warn('[Lv00 Lib] Marked.js failed:', e); }),
            this.jsPDF.load().catch(function(e) { console.warn('[Lv00 Lib] jsPDF failed:', e); }),
            this.matterJS.load().catch(function(e) { console.warn('[Lv00 Lib] Matter.js failed:', e); }),
            this.dayJS.load().catch(function(e) { console.warn('[Lv00 Lib] Day.js failed:', e); }),
            this.fileSaver.load().catch(function(e) { console.warn('[Lv00 Lib] FileSaver.js failed:', e); }),
            this.anime.load().catch(function(e) { console.warn('[Lv00 Lib] Anime.js failed:', e); }),
            this.xterm.load().catch(function(e) { console.warn('[Lv00 Lib] xterm.js failed:', e); }),
            this.clipboard.load().catch(function(e) { console.warn('[Lv00 Lib] Clipboard.js failed:', e); }),
            this.delaunator.load().catch(function(e) { console.warn('[Lv00 Lib] Delaunator failed:', e); }),
            this.turndown.load().catch(function(e) { console.warn('[Lv00 Lib] Turndown failed:', e); }),
            this.threeJS.load().catch(function(e) { console.warn('[Lv00 Lib] Three.js failed:', e); }),
            this.fuse.load().catch(function(e) { console.warn('[Lv00 Lib] Fuse.js failed:', e); }),
            this.uuid.load().catch(function(e) { console.warn('[Lv00 Lib] UUID failed:', e); }),
            this.crypto.load().catch(function(e) { console.warn('[Lv00 Lib] CryptoJS failed:', e); }),
            this.seedRandom.load().catch(function(e) { console.warn('[Lv00 Lib] SeedRandom failed:', e); }),
            this.pako.load().catch(function(e) { console.warn('[Lv00 Lib] Pako failed:', e); }),
            this.tinyQueue.load().catch(function(e) { console.warn('[Lv00 Lib] TinyQueue failed:', e); }),
            this.rbush.load().catch(function(e) { console.warn('[Lv00 Lib] RBush failed:', e); }),
            this.simpleStats.load().catch(function(e) { console.warn('[Lv00 Lib] SimpleStats failed:', e); }),
            this.earcut.load().catch(function(e) { console.warn('[Lv00 Lib] Earcut failed:', e); }),
            this.robustPredicates.load().catch(function(e) { console.warn('[Lv00 Lib] RobustPredicates failed:', e); }),
            this.glMatrix.load().catch(function(e) { console.warn('[Lv00 Lib] GLMatrix failed:', e); })
        ]).then(function() {
            console.log('[Lv00 Lib] Initialization complete');
        });
    },

    // 创建全局几何Canvas（使用Fabric.js）
    createGeometryCanvas: function(elementId, options) {
        options = options || {};
        return this.fabricJS.load().then(function() {
            return Lv00FabricJS.createCanvas(elementId, {
                width: options.width || 800,
                height: options.height || 600,
                backgroundColor: '#0a0a0a'
            });
        });
    },

    // 浣跨敤Math.js璁＄畻鍑犱綍闂
    solveGeometryProblem: function(problem) {
        return this.mathJS.load().then(function() {
            if (problem.type === 'triangle_area') {
                var a = problem.sides.a;
                var b = problem.sides.b;
                var c = problem.sides.c;
                var s = (a + b + c) / 2;
                return Lv00MathJS.evaluate('sqrt(' + s + ' * (' + s + ' - ' + a + ') * (' + s + ' - ' + b + ') * (' + s + ' - ' + c + '))');
            }
            return null;
        });
    },

    // 高亮代码面板中的所有代码块
    highlightAllCode: function() {
        this.highlightJS.highlightAll();
    },

    // 创建ECharts图表
    createChart: function(elementId, option, theme) {
        theme = theme || 'dark';
        return this.echarts.init(elementId, theme).then(function(chart) {
            chart.setOption(option);
            return chart;
        });
    },

    // 创建代码编辑器
    createCodeEditor: function(elementId, options) {
        return this.codeMirror.create(elementId, options);
    },

    // 浣跨敤Transformers.js杩涜鏂囨湰鐢熸垚
    generateText: function(prompt, maxLength) {
        maxLength = maxLength || 50;
        return this.transformersJS.generateText(prompt, maxLength);
    },

    // 使用Ollama进行本地LLM推理
    chatWithLocalLLM: function(model, messages) {
        return this.ollama.chat(model, messages);
    },

    // 使用TensorFlow.js创建简单预测模型
    createPredictionModel: function() {
        return this.tensorflowJS.createLinearModel();
    }
};

/**
 * ============================================================================
 *  命名空间管理
 * ============================================================================
 *
 *  统一命名空间：window.Lv00Libraries
 *  - 所有38个库封装对象均挂载在 window.Lv00Libraries 下
 *  - 推荐用法：Lv00Libraries.mathJS.load()、Lv00Libraries.d3.createSVG()
 *
 *  向后兼容别名：
 *  - 各模块的独立全局变量（如 Lv00MathJS、Lv00D3 等）保留，
 *    以确保现有代码和引用不受影响。
 *  - 两种访问方式等价：Lv00MathJS === Lv00Libraries.mathJS
 *
 *  调用约定：
 *  - 需要加载外部CDN的模块：先调用 .load() 再使用功能方法
 *  - 纯JavaScript实现的模块：可直接调用，.load() 立即resolve
 *  - 所有模块的 load() 方法均幂等，重复调用安全无副作用
 * ============================================================================
 */

// 全局导出 - 统一命名空间（主要入口）
window.Lv00Libraries = Lv00Libraries;

// 向后兼容别名 - 各模块独立全局变量（保持现有代码可用）
// 以下别名与 Lv00Libraries 中对应属性指向同一对象引用：
//   window.Lv00MathJS           === Lv00Libraries.mathJS
//   window.Lv00HighlightJS      === Lv00Libraries.highlightJS
//   window.Lv00FabricJS         === Lv00Libraries.fabricJS
//   window.Lv00Store            === Lv00Libraries.store
//   window.Lv00D3               === Lv00Libraries.d3
//   window.Lv00ECharts          === Lv00Libraries.echarts
//   window.Lv00Lodash           === Lv00Libraries.lodash
//   window.Lv00Axios            === Lv00Libraries.axios
//   window.Lv00CodeMirror       === Lv00Libraries.codeMirror
//   window.Lv00TensorFlowJS     === Lv00Libraries.tensorflowJS
//   window.Lv00TransformersJS   === Lv00Libraries.transformersJS
//   window.Lv00ONNXRuntime      === Lv00Libraries.onnxRuntime
//   window.Lv00LangChain        === Lv00Libraries.langChain
//   window.Lv00Ollama           === Lv00Libraries.ollama
//   window.Lv00Mermaid          === Lv00Libraries.mermaid
//   window.Lv00Cytoscape        === Lv00Libraries.cytoscape
//   window.Lv00Marked           === Lv00Libraries.marked
//   window.Lv00JsPDF            === Lv00Libraries.jsPDF
//   window.Lv00MatterJS         === Lv00Libraries.matterJS
//   window.Lv00DayJS            === Lv00Libraries.dayJS
//   window.Lv00FileSaver        === Lv00Libraries.fileSaver
//   window.Lv00Anime            === Lv00Libraries.anime
//   window.Lv00XTerm            === Lv00Libraries.xterm
//   window.Lv00Clipboard        === Lv00Libraries.clipboard
//   window.Lv00Delaunator       === Lv00Libraries.delaunator
//   window.Lv00Turndown         === Lv00Libraries.turndown
//   window.Lv00ThreeJS          === Lv00Libraries.threeJS
//   window.Lv00Fuse             === Lv00Libraries.fuse
//   window.Lv00UUID             === Lv00Libraries.uuid
//   window.Lv00Crypto           === Lv00Libraries.crypto
//   window.Lv00SeedRandom       === Lv00Libraries.seedRandom
//   window.Lv00Pako             === Lv00Libraries.pako
//   window.Lv00TinyQueue        === Lv00Libraries.tinyQueue
//   window.Lv00RBush            === Lv00Libraries.rbush
//   window.Lv00SimpleStats      === Lv00Libraries.simpleStats
//   window.Lv00Earcut           === Lv00Libraries.earcut
//   window.Lv00RobustPredicates === Lv00Libraries.robustPredicates
//   window.Lv00GLMatrix         === Lv00Libraries.glMatrix
